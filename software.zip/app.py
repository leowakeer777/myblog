import os
import sys
import pandas as pd
from flask import Flask, render_template, request, jsonify

# —— 1. 动态确定“基础路径”（basedir）:
# 如果是 PyInstaller 打包后的 exe，sys.frozen 会为 True，资源都在 sys._MEIPASS 目录里。
# 如果直接用 python 运行，则 sys.frozen 不存在，直接使用当前脚本所在的目录。
if getattr(sys, "frozen", False):
    # 打包后，PyInstaller 会在临时目录里解压所有“附加数据”
    basedir = sys._MEIPASS
else:
    basedir = os.path.abspath(os.path.dirname(__file__))

# —— 2. 初始化 Flask 时，让它知道模板路径在哪里 —— #
# 默认 Flask 会在 “脚本同级/templates” 目录找模板，但打包后模板在临时文件夹里的 “templates/” 里，
# 所以这里显式把 template_folder 定为 basedir/templates。
app = Flask(__name__, template_folder=os.path.join(basedir, "templates"))

def load_data():
    # 这里把 Excel 文件也放到 basedir 下去读取
    excel_path = os.path.join(basedir, "航班查询软件数据库.xlsx")
    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"找不到数据文件: {excel_path}")

    df = pd.read_excel(
        excel_path,
        parse_dates=["起飞时间"],
        engine="openpyxl"
    )
    # 重命名列
    df = df.rename(columns={
        "出港航班号":   "flight_no",
        "航空公司":     "airline",
        "起飞时间":     "departure_time",
        "目的地省份":   "province",
        "目的地城市":   "city",
        "机型":        "aircraft_type",
        "机型大小":     "size",
        "原机位":       "stand"
    })
    return df

# 全局加载一次 DataFrame
DF = load_data()

@app.route("/", methods=["GET", "POST"])
def index():
    provinces = sorted(DF["province"].dropna().unique().tolist())

    if request.method == "POST":
        selected_province = request.form.get("province", "").strip()
        selected_city     = request.form.get("city", "").strip()
        selected_airline  = request.form.get("airline", "").strip()
        selected_size     = request.form.get("size", "").strip()
    else:
        selected_province = ""
        selected_city     = ""
        selected_airline  = ""
        selected_size     = ""

    if selected_province:
        cities = sorted(
            DF[DF["province"] == selected_province]["city"]
            .dropna()
            .unique()
            .tolist()
        )
    else:
        cities = []

    if selected_province and selected_city:
        airlines = sorted(
            DF[
                (DF["province"] == selected_province) &
                (DF["city"] == selected_city)
            ]["airline"]
            .dropna()
            .unique()
            .tolist()
        )
        sizes = sorted(
            DF[
                (DF["province"] == selected_province) &
                (DF["city"] == selected_city)
            ]["size"]
            .dropna()
            .unique()
            .tolist()
        )
    else:
        airlines = []
        sizes    = []

    filtered_df = None
    message = ""

    if request.method == "POST":
        if not selected_province or not selected_city:
            message = "请先选择省份和城市！ (Please select both province and city.)"
        else:
            q = DF[
                (DF["province"] == selected_province) &
                (DF["city"] == selected_city)
            ].copy()

            if selected_airline:
                q = q[q["airline"] == selected_airline]
            if selected_size:
                q = q[q["size"] == selected_size]

            if q.empty:
                message = "没有找到符合条件的航班 (No matching flights found)."
            else:
                q = q.sort_values("departure_time")
                q["depart_str"] = q["departure_time"].dt.strftime("%H:%M")
                filtered_df = q[
                    ["airline", "flight_no", "depart_str", "aircraft_type"]
                ].to_dict(orient="records")
                message = f"共找到 {len(q)} 个航班 (Found {len(q)} flights)."

    return render_template(
        "index.html",
        provinces=provinces,
        cities=cities,
        airlines=airlines,
        sizes=sizes,
        selected_province=selected_province,
        selected_city=selected_city,
        selected_airline=selected_airline,
        selected_size=selected_size,
        filtered_df=filtered_df,
        message=message
    )

@app.route("/get_cities")
def get_cities():
    prov = request.args.get("province", "").strip()
    if not prov:
        return jsonify([])
    city_list = sorted(
        DF[DF["province"] == prov]["city"]
        .dropna()
        .unique()
        .tolist()
    )
    return jsonify(city_list)

@app.route("/get_airlines")
def get_airlines():
    prov = request.args.get("province", "").strip()
    city = request.args.get("city", "").strip()
    if not prov or not city:
        return jsonify([])
    airline_list = sorted(
        DF[
            (DF["province"] == prov) &
            (DF["city"] == city)
        ]["airline"]
        .dropna()
        .unique()
        .tolist()
    )
    return jsonify(airline_list)

@app.route("/get_sizes")
def get_sizes():
    prov = request.args.get("province", "").strip()
    city = request.args.get("city", "").strip()
    if not prov or not city:
        return jsonify([])
    size_list = sorted(
        DF[
            (DF["province"] == prov) &
            (DF["city"] == city)
        ]["size"]
        .dropna()
        .unique()
        .tolist()
    )
    return jsonify(size_list)

if __name__ == "__main__":
    # —— 可选：打包后自动打开浏览器 —— #
    def open_browser():
        import time, webbrowser
        time.sleep(1)
        webbrowser.open("http://127.0.0.1:5000/")

    if getattr(sys, "frozen", False):
        # 如果是被打包后的 exe，就启用自动打开浏览器
        import threading
        threading.Thread(target=open_browser, daemon=True).start()
        app.run(debug=False, host="127.0.0.1", port=5000)
    else:
        # 普通 python 运行时，不自动打开浏览器
        app.run(debug=True, host="127.0.0.1", port=5000)
