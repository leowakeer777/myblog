# 导入所需的库
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader


# 定义超参数
batch_size = 128  # 每批处理的数据
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # 是否用gpu或者cpu训练
Epoch = 100  # 训练轮次


# 对图像做处理，构建pipeline
pipeline = transforms.Compose([
    transforms.ToTensor(),  # 将图片转换为张量
    transforms.Normalize((0.1307,), (0.3081,))  # 图片归一化
])


# 下载，加载数据
# 下载数据
train_set = datasets.MNIST("data", train=True, download=True, transform=pipeline)
test_set = datasets.MNIST('data', train=False, download=True, transform=pipeline)
# 加载数据
train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=True)


# 构建网络模型
class HandwritingCNN(nn.Module):
    def __init__(self):
        super(HandwritingCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, 5)  # 卷积层（输入通道，输出通道，卷积核）
        self.conv2 = nn.Conv2d(10, 20, 3)
        self.fc1 = nn.Linear(20*10*10, 500)  # 全连接层（输入通道，输出通道）
        self.fc2 = nn.Linear(500, 10)

    def forward(self, x):
        input_size = x.size(0)  # 图片送入的张量形式：batch_size*1*28*28
        x = self.conv1(x)  # 输入：bs*1*28*28 输出：bs*10*24*24（24=28-5+1）
        x = F.relu(x)  # 激活函数
        x = F.max_pool2d(x, 2, 2)  # 池化，输出：bs*10*12*12
        x = self.conv2(x)  # 输出：bs*20*10*10，计算方法同上
        x = F.relu(x)
        x = x.view(input_size, -1)  # 张量化，准备送入全连接层。-1表示自动计算维度，为20*10*10=2000
        x = self.fc1(x)  # 送入全连接层，输出：500
        x = F.relu(x)
        x = self.fc2(x)  # 输出：10
        output = F.log_softmax(x, dim=1)  # dim=1表示按行计算，用柔性最大值拟合概率
        return output


# 定义优化器
model = HandwritingCNN().to(device)
optimizer = optim.Adam(model.parameters())


# 定义训练方法
def train_model(model, device, train_loader, optimizer, epoch):
    # 模型训练
    model.train()
    for batch_idx, (data, tag) in enumerate(train_loader):
        data, tag = data.to(device), tag.to(device)  # 部署到gpu或cpu
        optimizer.zero_grad()  # 梯度初始化为0
        output = model(data)  # 输出
        loss = F.cross_entropy(output, tag)  # loss函数,定义为交叉熵
        loss.backward()  # BP
        optimizer.step()  # 更新参数
        if batch_idx % 3000 == 0:
            print('Train Epoch : {} \t Loss : {:.6f}'.format(epoch, loss.item()))  # 每3000张图片打印


# 定义测试方法
def test_model(model, device, test_loader):
    model.eval()  # 模型测试
    correct = 0.0  # 正确率
    test_loss = 0.0  # 测试损失
    with torch.no_grad():  # 防止参数更新，防止测试集用作训练
        for data, tag in test_loader:
            data, tag = data.to(device), tag.to(device)  # 部署
            output = model(data)  # 测试数据
            test_loss += F.cross_entropy(output, tag).item()  # 测试损失
            prediction = output.argmax(dim=1)  # 返回预测分类的索引（哪个数字？）
            correct += prediction.eq(tag.view_as(prediction)).sum().item()
        test_loss /= len(test_loader.dataset)
        print('Test ------- Average loss : {:.4f}, Accuracy : {:.3f}%\n'.format(
            test_loss, 100.0 * correct / len(test_loader.dataset)))


if __name__ == '__main__':
    # 调用方法，输出结果
    for epoch in range(1, Epoch + 1):
        train_model(model, device, train_loader, optimizer, epoch)
        test_model(model, device, test_loader)
    torch.save(model.state_dict(), 'model0.pt')
