import torch
import train
from PIL import Image

detect = train.HandwritingCNN().to(train.device)
detect.load_state_dict(torch.load('model0.pt'))


def resize(path):
    img = Image.open(path).resize((28, 28)).convert('L')
    # img.show()
    return img


def predict(path):
    img = resize(path)
    img = train.pipeline(img)  # img送入pipeline
    img.view(-1, 784)
    img = img.to(train.device)  # 部署到gpu
    result = detect(img)
    prediction = result.argmax(dim=1)
    return prediction.item()


# result = predict('handwriting.png')
# a, pre = torch.max(result.data, dim=1)
# print(result)
# print(a)
# print(pre.item())
