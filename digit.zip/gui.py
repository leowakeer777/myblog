import sys
import detect
from PyQt5.QtWidgets import QApplication, QMainWindow, QAction, QLabel, QMessageBox
from PyQt5.QtGui import QPainter, QPen, QFont, QPixmap, QIcon
from PyQt5.QtCore import Qt


class Palette(QMainWindow):
    def __init__(self):
        super(Palette, self).__init__()
        self.initUI()

    def initUI(self):
        self.setMouseTracking(False)
        self.pos_xy = [(-1, -1)]
        self.statusbar = self.statusBar()
        self.statusbar.setFont(QFont('Roman times', 14))
        self.statusbar.showMessage('准备')
        act1 = QAction('重写', self)
        act1.setStatusTip('清空全部笔画')
        act1.triggered.connect(self.clear)
        act2 = QAction('撤回', self)
        act2.triggered.connect(self.back)
        act2.setStatusTip('撤销当前笔画')
        act3 = QAction('识别', self)
        act3.setStatusTip('识别当前数字')
        act3.triggered.connect(self.identify)

        menubar = self.menuBar()
        menubar.addAction(act1)
        menubar.addAction(act2)
        menubar.addAction(act3)
        menubar.setFont(QFont('Roman times', 16))
        self.print_ = False

        self.setGeometry(300, 300, 600, 600)
        self.setWindowTitle('模式识别小系统')
        self.setWindowIcon(QIcon('icon.png'))
        self.setStyleSheet('QLabel{background-color:rgb(220,220,200)}')
        self.show()

    def paintEvent(self, event):
        qp1 = QPainter()
        qp1.begin(self)
        self.handWrite1(qp1)
        qp1.end()
        if self.print_ is True:
            pix = QPixmap()
            pix.load('background.png')
            qp2 = QPainter()
            qp2.begin(pix)
            self.handWrite2(qp2)
            qp2.end()
            pix.save('handwriting.png')
            self.print_ = False
            result = str(detect.predict('handwriting.png'))
            QMessageBox.question(self, "识别结果", '你写的数字为：' + result, QMessageBox.Ok, QMessageBox.Ok)

    def handWrite1(self, qp):
        qp.drawRect(50, 50, 400, 500)

        pen = QPen(Qt.black, 30, Qt.SolidLine)
        pen.setCapStyle(Qt.RoundCap)
        qp.setPen(pen)

        if len(self.pos_xy) > 1:
            point_start = self.pos_xy[0]
            for pos_tem in self.pos_xy:
                point_end = pos_tem
                if point_start == (-1, -1) or point_end == (-1, -1):
                    point_start = point_end
                    continue
                qp.drawLine(point_start[0], point_start[1], point_end[0], point_end[1])
                point_start = point_end

    def handWrite2(self, qp):
        pen = QPen(Qt.white, 30, Qt.SolidLine)
        pen.setCapStyle(Qt.RoundCap)
        qp.setPen(pen)

        if len(self.pos_xy) > 1:
            point_start = self.pos_xy[0]
            for pos_tem in self.pos_xy:
                point_end = pos_tem
                if point_start == (-1, -1) or point_end == (-1, -1):
                    point_start = point_end
                    continue
                qp.drawLine(point_start[0] - 50, point_start[1] - 50,
                            point_end[0] - 50, point_end[1] - 50)
                point_start = point_end

    def mouseMoveEvent(self, event):
        x, y = event.x(), event.y()
        if 50 < x < 50 + 400 and 50 < y < 50 + 500:
            pos_tem = (x, y)
            self.pos_xy.append(pos_tem)
            self.statusbar.showMessage('正在输入 ...')
        else:
            pos_stop = (-1, -1)
            if self.pos_xy[-1] != pos_stop:
                self.pos_xy.append(pos_stop)
            self.statusbar.showMessage('准备')
        self.update()

    def mouseReleaseEvent(self, event):
        pos_stop = (-1, -1)
        if self.pos_xy[-1] != pos_stop:
            self.pos_xy.append(pos_stop)
        self.statusbar.showMessage('准备')
        self.update()

    def clear(self):
        self.pos_xy = [(-1, -1)]
        self.update()

    def back(self):
        if self.pos_xy == [(-1, -1)]:
            return
        pos_xy = self.pos_xy[::-1]
        index_xy = len(pos_xy) - pos_xy.index((-1, -1), 1)
        self.pos_xy = self.pos_xy[:index_xy]
        self.update()

    def identify(self):
        self.print_ = True
        self.update()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    pyqt_learn = Palette()
    pyqt_learn.show()
    sys.exit(app.exec_())
